# Default Admin Credentials

## Login Information
- **Email:** admin@gmail.com
- **Password:** 1234

## Special Permissions
The default admin (admin@gmail.com) has special privileges:

1. **Can delete other admin users** - Regular admin users cannot delete other admins
2. **Cannot be deleted** - The default admin account is protected from deletion
3. **Full system access** - Has access to all admin features

## User Management Rules
- **Regular admins** can only delete regular users (USER role)
- **Default admin** can delete both regular users and other admin users
- **No admin** can delete their own account
- **Users with bookings** cannot be deleted until their bookings are removed first

## Visual Indicators
In the user management page:
- Default admin is marked with a "Default Admin" badge
- Delete button is disabled for the default admin
- Tooltip shows "Cannot delete default admin" when hovering over the disabled button

## Security Notes
- The default admin password should be changed after first login for security
- This account serves as the system's root administrator
- Keep these credentials secure and limit access to trusted personnel only 