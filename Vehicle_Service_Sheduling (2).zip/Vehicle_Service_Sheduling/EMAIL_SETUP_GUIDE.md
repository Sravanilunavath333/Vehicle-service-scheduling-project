# Email Notification Setup Guide

## Overview
The vehicle service scheduling system now includes email notifications for successful service bookings. When a user books a service, they will automatically receive a confirmation email with all the booking details.

## Features
- ✅ Automatic email notifications on successful bookings
- ✅ Detailed booking information in email
- ✅ Vehicle and service details included
- ✅ Professional email formatting
- ✅ Error handling (booking process continues even if email fails)

## Email Content Includes:
- Booking ID and status
- Service type, price, and duration
- Vehicle brand, model, and registration number
- Booking date and time
- Service description
- Additional notes (if any)
- Important instructions for the appointment

## Setup Instructions

### 1. Gmail Account Setup
1. Use a Gmail account for sending emails
2. Enable 2-Factor Authentication on your Gmail account
3. Generate an App Password:
   - Go to Google Account settings
   - Security → 2-Step Verification → App passwords
   - Generate a new app password for "Mail"

### 2. Update Application Properties
Edit `src/main/resources/application.properties`:

```properties
# Email Configuration (Gmail SMTP)
spring.mail.host=smtp.gmail.com
spring.mail.port=587
spring.mail.username=your-email@gmail.com
spring.mail.password=your-app-password
spring.mail.properties.mail.smtp.auth=true
spring.mail.properties.mail.smtp.starttls.enable=true
spring.mail.properties.mail.smtp.starttls.required=true
```

**Replace:**
- `your-email@gmail.com` with your Gmail address
- `your-app-password` with the app password generated in step 1

### 3. Test Email Functionality
1. Start the application
2. Visit: `http://localhost:8080/test-email/send-test`
3. Check if you receive the test email

### 4. Production Usage
- The email feature is automatically triggered when a user books a service
- No additional code changes needed
- Emails are sent to the user's registered email address

## Email Template Example

```
Dear John Doe,

Your service booking has been confirmed successfully!

BOOKING DETAILS:
================
Booking ID: 123
Service Type: Full Service
Service Price: Rs. 2499.0
Service Duration: 2 hours
Booking Date & Time: 15/12/2024 14:30
Status: PENDING

VEHICLE DETAILS:
================
Brand: Maruti Suzuki
Model: Swift
Registration Number: MH12AB1234

SERVICE DESCRIPTION:
===================
Complete vehicle inspection and maintenance

IMPORTANT INFORMATION:
======================
- Please arrive 10 minutes before your scheduled appointment
- Bring your vehicle registration documents
- Payment will be collected at the service center
- For any queries, please contact our customer service

Thank you for choosing our service!

Best regards,
Vehicle Service Center Team
```

## Troubleshooting

### Email Not Sending
1. Check Gmail credentials in application.properties
2. Verify app password is correct
3. Ensure 2-Factor Authentication is enabled
4. Check application logs for error messages

### Common Issues
- **Authentication failed**: Check username and app password
- **Connection timeout**: Check internet connection and firewall settings
- **Email not received**: Check spam folder

## Security Notes
- Never commit real email credentials to version control
- Use environment variables for production deployments
- App passwords are more secure than regular passwords
- Consider using email service providers like SendGrid for production

## Files Modified/Added
- `pom.xml` - Added Spring Boot Mail dependency
- `EmailService.java` - Email service interface
- `EmailServiceImpl.java` - Email service implementation
- `BookingServiceImpl.java` - Added email notification call
- `application.properties` - Email configuration
- `EmailTestController.java` - Test controller for email functionality 