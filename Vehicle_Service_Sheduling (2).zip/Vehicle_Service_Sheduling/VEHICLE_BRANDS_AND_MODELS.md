# Vehicle Brands and Models - Database Integration

## Overview
The vehicle service scheduling system fetches vehicle brands and models from the database, not from hardcoded data. This ensures dynamic and maintainable data management.

## How It Works

### 1. Database Structure
- **vehicle_brand** table: Stores vehicle brand information (id, name)
- **vehicle_model** table: Stores vehicle model information (id, name, brand_id)

### 2. Data Initialization
- Vehicle brands and models are populated via `src/main/resources/data.sql`
- The file contains comprehensive data for 15+ brands and 100+ models
- Data is loaded automatically when the application starts

### 3. Service Layer
- **VehicleBrandService**: Fetches all vehicle brands from database
- **VehicleModelService**: Fetches models for a specific brand ID

### 4. Controller Layer
- **BookingController.showBookingForm()**: Loads all brands for the booking form
- **BookingController.getModelsByBrand()**: API endpoint to fetch models by brand ID

### 5. Frontend Integration
- HTML template (`book_service.html`) displays brands in a dropdown
- JavaScript makes AJAX calls to `/booking/api/models?brandId={id}` to load models dynamically
- Models are populated in a second dropdown when a brand is selected

## API Endpoints

### Get All Brands
```
GET /test/brands
```
Returns all vehicle brands from the database.

### Get Models by Brand
```
GET /booking/api/models?brandId={brandId}
```
Returns all models for a specific brand ID.

## Database Queries
- Brands: `SELECT * FROM vehicle_brand ORDER BY name`
- Models: `SELECT * FROM vehicle_model WHERE brand_id = ?`

## Benefits
1. **Dynamic Data**: No hardcoded values in the application
2. **Maintainable**: Easy to add/remove brands and models via database
3. **Scalable**: Can handle large numbers of brands and models
4. **Real-time**: Changes to database are immediately reflected in the UI

## Testing
Use the test endpoints to verify data is loaded correctly:
- `http://localhost:8080/test/brands` - View all brands
- `http://localhost:8080/test/models?brandId=1` - View models for brand ID 1 