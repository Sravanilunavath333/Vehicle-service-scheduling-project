# Vehicle Dataset Guide

## Overview
The vehicle service scheduling system now includes a comprehensive dataset of vehicle brands and models that will be automatically loaded into the database when the application starts.

## Dataset Statistics

### Vehicle Brands: 30 Brands
1. **Maruti Suzuki** - 16 models
2. **Hyundai** - 14 models  
3. **Tata** - 13 models
4. **Mahindra** - 13 models
5. **Kia** - 7 models
6. **Toyota** - 11 models
7. **Honda** - 8 models
8. **Volkswagen** - 8 models
9. **Skoda** - 8 models
10. **Renault** - 7 models
11. **Ford** - 8 models
12. **Nissan** - 6 models
13. **BMW** - 10 models
14. **Mercedes-Benz** - 10 models
15. **Audi** - 10 models
16. **MG** - 5 models
17. **Volvo** - 6 models
18. **Jaguar** - 6 models
19. **Land Rover** - 6 models
20. **Jeep** - 5 models
21. **Mini** - 4 models
22. **Lexus** - 6 models
23. **Porsche** - 7 models
24. **Ferrari** - 5 models
25. **Lamborghini** - 4 models
26. **Aston Martin** - 4 models
27. **Bentley** - 4 models
28. **Rolls-Royce** - 5 models
29. **Maserati** - 5 models
30. **McLaren** - 4 models

**Total Models: 300+ vehicle models**

## How It Works

### 1. Database Initialization
- When the application starts, `data.sql` is automatically executed
- Vehicle brands and models are inserted into the database
- Data is loaded only if tables are empty (prevents duplicates)

### 2. Data Structure
```sql
-- Vehicle Brands Table
CREATE TABLE vehicle_brand (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL UNIQUE
);

-- Vehicle Models Table  
CREATE TABLE vehicle_model (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    brand_id BIGINT,
    FOREIGN KEY (brand_id) REFERENCES vehicle_brand(id)
);
```

### 3. Booking Form Integration
When users visit the booking page (`/booking/new`):

1. **Brand Loading**: All vehicle brands are fetched from database
2. **Brand Display**: Brands appear in the first dropdown
3. **Model Loading**: When a brand is selected, models are loaded via AJAX
4. **Dynamic Updates**: Models dropdown updates based on selected brand

### 4. API Endpoints
- **Get All Brands**: `GET /booking/new` (loads brands in form)
- **Get Models by Brand**: `GET /booking/api/models?brandId={id}` (AJAX call)

## Vehicle Categories

### Economy Brands
- Maruti Suzuki, Hyundai, Tata, Mahindra, Kia, Renault, Ford, Nissan

### Mid-Range Brands  
- Toyota, Honda, Volkswagen, Skoda, MG

### Luxury Brands
- BMW, Mercedes-Benz, Audi, Volvo, Jaguar, Land Rover, Lexus

### Premium Sports Brands
- Porsche, Ferrari, Lamborghini, Aston Martin, Bentley, Rolls-Royce, Maserati, McLaren

## Popular Models by Brand

### Maruti Suzuki
- Swift, Baleno, Dzire, Wagon R, Vitara Brezza, Ertiga

### Hyundai  
- i20, Creta, Verna, Venue, Grand i10 Nios, Tucson

### Tata
- Nexon, Altroz, Harrier, Safari, Tiago, Punch

### Mahindra
- Thar, XUV700, Scorpio-N, Bolero, XUV300

### Toyota
- Innova Crysta, Fortuner, Glanza, Camry, Corolla

### Honda
- City, Amaze, WR-V, Civic, CR-V

### BMW
- 3 Series, 5 Series, X1, X3, X5, 7 Series

### Mercedes-Benz
- C-Class, E-Class, GLA, GLC, S-Class, A-Class

### Audi
- A4, A6, Q3, Q5, Q7, A3, A8

## Data Management

### Adding New Brands/Models
To add new vehicle brands or models:

1. **Edit `data.sql`** file
2. **Add brand**: `INSERT INTO vehicle_brand (name) VALUES ('New Brand');`
3. **Add models**: `INSERT INTO vehicle_model (name, brand_id) SELECT 'New Model', id FROM vehicle_brand WHERE name = 'New Brand';`
4. **Restart application** to load new data

### Database Queries
```sql
-- Get all brands
SELECT * FROM vehicle_brand ORDER BY name;

-- Get models for a specific brand
SELECT vm.name FROM vehicle_model vm 
JOIN vehicle_brand vb ON vm.brand_id = vb.id 
WHERE vb.name = 'Maruti Suzuki';

-- Get brand and model count
SELECT vb.name, COUNT(vm.id) as model_count 
FROM vehicle_brand vb 
LEFT JOIN vehicle_model vm ON vb.id = vm.brand_id 
GROUP BY vb.id, vb.name 
ORDER BY vb.name;
```

## Benefits

### For Users
- ✅ **Comprehensive Selection**: 30 brands and 300+ models
- ✅ **Easy Navigation**: Dropdown-based selection
- ✅ **Real-time Updates**: Models load dynamically
- ✅ **Accurate Data**: Database-driven, not hardcoded

### For System
- ✅ **Scalable**: Easy to add new brands/models
- ✅ **Maintainable**: Centralized data management
- ✅ **Performance**: Optimized database queries
- ✅ **Reliability**: Data consistency across sessions

## Testing the Dataset

### 1. Check Data Loading
```bash
# Start application and check logs for:
"Fetched X vehicle brands from database"
```

### 2. Test Brand Loading
Visit: `http://localhost:8080/booking/new`
- Should see 30 brands in the dropdown

### 3. Test Model Loading
- Select any brand from dropdown
- Should see corresponding models load

### 4. API Testing
```bash
# Test brands API
curl http://localhost:8080/booking/api/models?brandId=1

# Should return JSON array of models for brand ID 1
```

## File Locations
- **Data File**: `src/main/resources/data.sql`
- **Entities**: `src/main/java/com/example/demo/Entity/VehicleBrand.java`, `VehicleModel.java`
- **Services**: `src/main/java/com/example/demo/Service/VehicleBrandService.java`, `VehicleModelService.java`
- **Controller**: `src/main/java/com/example/demo/Controller/BookingController.java`
- **Template**: `src/main/resources/templates/booking/book_service.html`

The vehicle dataset is now fully integrated and will provide users with a comprehensive selection of vehicle brands and models when booking services! 