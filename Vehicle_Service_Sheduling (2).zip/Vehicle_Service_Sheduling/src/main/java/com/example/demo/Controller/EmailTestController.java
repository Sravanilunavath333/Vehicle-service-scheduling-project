package com.example.demo.Controller;

import com.example.demo.Entity.Booking;
import com.example.demo.Entity.ServiceType;
import com.example.demo.Entity.User;
import com.example.demo.Service.EmailService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDateTime;

@RestController
@RequestMapping("/test-email")
public class EmailTestController {

    @Autowired
    private EmailService emailService;

    @GetMapping("/send-test")
    public ResponseEntity<String> sendTestEmail() {
        try {
            // Create a test user
            User testUser = new User();
            testUser.setUsername("Test User");
            testUser.setEmail("your-email-here@example.com"); // Replace with your email for testing
            
            // Create a test service
            ServiceType testService = new ServiceType();
            testService.setName("Test Service");
            testService.setPrice(1500.0);
            testService.setDuration("1 hour");
            testService.setDescription("This is a test service description");
            testService.setAvailable(true);
            
            // Create a test booking
            Booking testBooking = new Booking();
            testBooking.setUser(testUser);
            testBooking.setServiceType(testService);
            testBooking.setBookingDate(LocalDateTime.now().plusDays(1));
            testBooking.setStatus(Booking.BookingStatus.PENDING);
            testBooking.setVehicleBrand("Test Brand");
            testBooking.setVehicleModel("Test Model");
            testBooking.setVehicleRegistrationNumber("TEST123");
            testBooking.setNotes("This is a test booking");
            
            // Send the email
            emailService.sendBookingConfirmationEmail(testBooking);
            
            return ResponseEntity.ok("Test email sent successfully! Check your email inbox.");
        } catch (Exception e) {
            e.printStackTrace(); // Print stack trace for debugging
            return ResponseEntity.badRequest().body("Failed to send test email: " + e.getMessage());
        }
    }
    
    @GetMapping("/simple-test")
    public ResponseEntity<String> simpleEmailTest() {
        try {
            // Simple test to check if email configuration is working
            return ResponseEntity.ok("Email test endpoint is working. Use /send-test to send actual email.");
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("Error: " + e.getMessage());
        }
    }
} 