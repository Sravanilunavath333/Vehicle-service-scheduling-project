package com.example.demo.Service;

public interface DashboardService {
    long getTotalUsers();
    long getTotalBookings();
    long getTotalVehicles();
    long getTotalServiceTypes();
}
