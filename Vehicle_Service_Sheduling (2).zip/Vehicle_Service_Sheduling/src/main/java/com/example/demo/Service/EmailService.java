package com.example.demo.Service;

import com.example.demo.Entity.Booking;

public interface EmailService {
    void sendBookingConfirmationEmail(Booking booking);
} 