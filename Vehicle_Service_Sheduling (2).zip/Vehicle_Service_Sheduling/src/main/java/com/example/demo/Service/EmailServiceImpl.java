package com.example.demo.Service;

import com.example.demo.Entity.Booking;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import java.time.format.DateTimeFormatter;

@Service
public class EmailServiceImpl implements EmailService {

    @Autowired
    private JavaMailSender mailSender;

    @Override
    public void sendBookingConfirmationEmail(Booking booking) {
        try {
            SimpleMailMessage message = new SimpleMailMessage();
            message.setTo(booking.getUser().getEmail());
            
            // Handle case where booking ID might be null (for test bookings)
            String bookingId = booking.getId() != null ? booking.getId().toString() : "TEST";
            message.setSubject("Service Booking Confirmation - Booking ID: " + bookingId);
            
            String emailContent = buildBookingConfirmationEmail(booking);
            message.setText(emailContent);
            
            mailSender.send(message);
            System.out.println("Booking confirmation email sent successfully to: " + booking.getUser().getEmail());
        } catch (Exception e) {
            System.err.println("Failed to send booking confirmation email: " + e.getMessage());
            // Don't throw exception to avoid breaking the booking process
        }
    }
    
    private String buildBookingConfirmationEmail(Booking booking) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");
        
        StringBuilder emailContent = new StringBuilder();
        emailContent.append("Dear ").append(booking.getUser().getUsername()).append(",\n\n");
        emailContent.append("Your service booking has been confirmed successfully!\n\n");
        emailContent.append("BOOKING DETAILS:\n");
        emailContent.append("================\n");
        
        // Handle case where booking ID might be null
        String bookingId = booking.getId() != null ? booking.getId().toString() : "TEST";
        emailContent.append("Booking ID: ").append(bookingId).append("\n");
        
        emailContent.append("Service Type: ").append(booking.getServiceType().getName()).append("\n");
        emailContent.append("Service Price: Rs. ").append(booking.getServiceType().getPrice()).append("\n");
        emailContent.append("Service Duration: ").append(booking.getServiceType().getDuration()).append("\n");
        emailContent.append("Booking Date & Time: ").append(booking.getBookingDate().format(formatter)).append("\n");
        emailContent.append("Status: ").append(booking.getStatus()).append("\n\n");
        
        emailContent.append("VEHICLE DETAILS:\n");
        emailContent.append("================\n");
        emailContent.append("Brand: ").append(booking.getVehicleBrand()).append("\n");
        emailContent.append("Model: ").append(booking.getVehicleModel()).append("\n");
        emailContent.append("Registration Number: ").append(booking.getVehicleRegistrationNumber()).append("\n\n");
        
        if (booking.getNotes() != null && !booking.getNotes().trim().isEmpty()) {
            emailContent.append("ADDITIONAL NOTES:\n");
            emailContent.append("================\n");
            emailContent.append(booking.getNotes()).append("\n\n");
        }
        
        emailContent.append("SERVICE DESCRIPTION:\n");
        emailContent.append("===================\n");
        emailContent.append(booking.getServiceType().getDescription()).append("\n\n");
        
        emailContent.append("IMPORTANT INFORMATION:\n");
        emailContent.append("======================\n");
        emailContent.append("- Please arrive 10 minutes before your scheduled appointment\n");
        emailContent.append("- Bring your vehicle registration documents\n");
        emailContent.append("- Payment will be collected at the service center\n");
        emailContent.append("- For any queries, please contact our customer service\n\n");
        
        emailContent.append("Thank you for choosing our service!\n\n");
        emailContent.append("Best regards,\n");
        emailContent.append("Vehicle Service Center Team");
        
        return emailContent.toString();
    }
} 