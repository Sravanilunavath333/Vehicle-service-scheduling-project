package com.example.demo.Service;

import com.example.demo.Entity.VehicleBrand;
import java.util.List;

public interface VehicleBrandService {
    List<VehicleBrand> getAllBrands();
} 