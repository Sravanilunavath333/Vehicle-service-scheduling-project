package com.example.demo.Service;

import com.example.demo.Entity.VehicleModel;
import com.example.demo.Repository.VehicleModelRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class VehicleModelServiceImpl implements VehicleModelService {

    @Autowired
    private VehicleModelRepository modelRepository;

    @Override
    public List<VehicleModel> getModelsByBrandId(Long brandId) {
        List<VehicleModel> models = modelRepository.findByBrand_Id(brandId);
        System.out.println("✅ Fetched " + models.size() + " vehicle models for brand ID: " + brandId);
        if (models.isEmpty()) {
            System.out.println("⚠️  Warning: No models found for brand ID: " + brandId);
        } else {
            System.out.println("📋 Available models: " + models.stream().map(VehicleModel::getName).toList());
        }
        return models;
    }
} 