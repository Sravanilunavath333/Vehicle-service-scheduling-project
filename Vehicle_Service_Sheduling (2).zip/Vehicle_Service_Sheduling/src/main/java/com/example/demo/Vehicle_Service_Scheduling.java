package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Vehicle_Service_Scheduling{

	public static void main(String[] args) {
		SpringApplication.run(Vehicle_Service_Scheduling.class, args);
	}

}
 