package com.example.demo.dto;

import jakarta.validation.constraints.NotNull;
import lombok.Data;
import java.time.LocalDateTime;

@Data
public class BookingRequest {

    @NotNull(message = "Vehicle brand is required")
    private String vehicleBrand;

    @NotNull(message = "Vehicle model is required")
    private String vehicleModel;

    @NotNull(message = "Vehicle registration number is required")
    private String vehicleRegistrationNumber;

    @NotNull(message = "Service type is required")
    private Long serviceTypeId;

    @NotNull(message = "Booking date is required")
    private LocalDateTime bookingDate;

    private String notes;
} 